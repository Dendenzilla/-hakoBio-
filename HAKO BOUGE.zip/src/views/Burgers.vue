<template>
<div>
    <div>buuuuuuurgers</div>
    <Burger/>
    </div>
</template>

<script>
import Burger from '../components/Burger.vue'
export default {
    components: {
        Burger
    }
}
</script>

<style>

</style>
