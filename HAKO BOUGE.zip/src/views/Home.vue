<template>
    <div>
        <Chatbot/>
    </div>
</template>

<script>
import Chatbot from '../components/Chatbot.vue'
export default {
name:'home',
components: {
    Chatbot
  }
}
</script>

<style>

</style>
